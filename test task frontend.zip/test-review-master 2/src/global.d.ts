declare global {
    interface Window {
        allTodosIsDone: boolean;
    }
}

export {}
