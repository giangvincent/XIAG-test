Expected results, step by step:
- Initialize git in root dir
- Do a code review in english. Leave review comments not only about the application errors, but also the structure/codestyle
- Make commit(s)

App description:
Expandable todo-list. Each task can be assigned to user and marked as done. Data should be stored only in state, ie available until you reload page. 
