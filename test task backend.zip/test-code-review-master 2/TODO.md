Expected results, step by step:
- Initialize git in root dir
- Do a code review in English. Review not only the application errors, but also the architecture/codestyle by comments
- Make commits
- Archive the code and send it back to us
