<?php

namespace App;

class Application
{
    public function run()
    {
        // TODO: implement routes initialization, handle request, etc
    }
}
