<?php

namespace App\Model;

class NotFoundException extends \Exception
{
}
